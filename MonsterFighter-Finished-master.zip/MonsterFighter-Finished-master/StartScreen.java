import java.util.*;
import java.lang.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import java.net.URL;

public class StartScreen extends JPanel implements ActionListener
{
	JButton newGameButton = new JButton("New Game");
	JButton loadGameButton = new JButton("Load Game");
	JButton highScoreButton = new JButton("High Scores");
	JButton exitButton = new JButton("Exit Game");

	public StartScreen()
	{
		this.setLayout(null);
		this.add(newGameButton);
		this.add(loadGameButton);
		this.add(highScoreButton);
		this.add(exitButton);
		newGameButton.setBounds(300,150,200,50);
		loadGameButton.setBounds(300,200,200,50);
		highScoreButton.setBounds(300,250,200,50);
		exitButton.setBounds(300,300,200,50);
		newGameButton.addActionListener(this);
		loadGameButton.addActionListener(this);
		highScoreButton.addActionListener(this);
		exitButton.addActionListener(this);

	}

	public void paintComponent(Graphics g)
	{
		g.setColor(Color.GRAY);
		g.fillOval(0, 300, 350, 150);
		g.fillOval(450, 0, 350, 150);
		try{
			URL url = new URL("https://fiverr-res.cloudinary.com/images/t_main1,q_auto,f_auto,q_auto,f_auto/gigs/204364595/original/86db6005cd51b4f60e71cca277f603a82cf5646a/draw-a-pixel-pokemon-battle-background.png");
			ImageIcon image = new ImageIcon(url);
			g.drawImage(image.getImage(),0,0,800,450,null);
			}catch(Exception e){};
		try{
			ImageIcon image = new ImageIcon("Images/Mimikyu_Link.png");
			g.drawImage(image.getImage(),300,150,-150,250,null);
			}catch(Exception e){};
	}

	public void actionPerformed(ActionEvent e)
	{
		if(e.getSource() == loadGameButton)
		{
			Main.gameUX.switchGameState(GameUX.GameState.LOAD_GAME);
		}
		else if(e.getSource() == newGameButton)
		{
			Main.gameUX.switchGameState(GameUX.GameState.NEW_GAME);
		}
		else if(e.getSource() == highScoreButton)
		{
			Main.gameUX.switchGameState(GameUX.GameState.HIGH_SCORE);
		}
		else if(e.getSource() == exitButton)
		{
			System.exit(0);
		}
	}
}