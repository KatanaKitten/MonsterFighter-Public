public class HighScore {
        public String playerName;
        public int playerScore;

        public HighScore(String playerName, int playerScore) {
            this.playerName = playerName;
            this.playerScore = playerScore;
        }
        public String getPlayerName() {
            return playerName;
        }
        public int getPlayerScore() {
            return playerScore;
        }
    }