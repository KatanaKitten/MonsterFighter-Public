import java.util.*;
import java.lang.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import java.net.URL;

public class Game extends JPanel implements ActionListener

{
	// instantiate Randomizor, scanner, counters, monster level, monster array, and player
		public Random rand = new Random();
		public Scanner scanner = new Scanner(System.in);
		public Player player = new Player("null",100,40,100);
		public int counter = 0;
		public int blockCounter = 0; 
		public int monsterLevelCounter = 0;
		public int monsterLevel = 0;
		public Monster[] monsters = new Monster[10];
		public Monster enemy = new Monster("null",1,1,1);

		public JButton attackButton;
		public JButton specialButton;
		public JButton blockButton;
		public JButton saveButton;
		private JComboBox<File> saveFileSelector = new JComboBox<File>();

		public int gameState = 0;

		public File file;
	
		public Game()
		{
			this.setLayout(null);


			attackButton = new JButton("Attack");
			this.add(attackButton);

			specialButton = new JButton("Special");
			this.add(specialButton);

			blockButton = new JButton("Block");
			this.add(blockButton);

			saveButton = new JButton("Save");
			this.add(saveButton);


			attackButton.setBounds(400,300,100,50);
			specialButton.setBounds(500,300,100,50);
			blockButton.setBounds(400,350,100,50);
			saveButton.setBounds(500,350,100,50);


			attackButton.addActionListener(this);
			specialButton.addActionListener(this);
			blockButton.addActionListener(this);
			saveButton.addActionListener(this);
			saveFileSelector.addItem(new File("Saves/SaveFile1.txt"));
			saveFileSelector.addItem(new File("Saves/SaveFile2.txt"));
			saveFileSelector.addItem(new File("Saves/SaveFile3.txt"));
			saveFileSelector.addItem(new File("Saves/SaveFile4.txt"));
			saveFileSelector.addItem(new File("Saves/SaveFile5.txt"));
		}
		public Game(int gameState)
		{
			this.gameState = gameState;

			
			this.setLayout(null);

			
			attackButton = new JButton("Attack");
			this.add(attackButton);

			specialButton = new JButton("Special");
			this.add(specialButton);

			blockButton = new JButton("Block");
			this.add(blockButton);

			saveButton = new JButton("Save");
			this.add(saveButton);


			attackButton.setBounds(400,300,100,50);
			specialButton.setBounds(500,300,100,50);
			blockButton.setBounds(400,350,100,50);
			saveButton.setBounds(500,350,100,50);


			attackButton.addActionListener(this);
			specialButton.addActionListener(this);
			blockButton.addActionListener(this);
			saveButton.addActionListener(this);
			saveFileSelector.addItem(new File("Saves/SaveFile1.txt"));
			saveFileSelector.addItem(new File("Saves/SaveFile2.txt"));
			saveFileSelector.addItem(new File("Saves/SaveFile3.txt"));
			saveFileSelector.addItem(new File("Saves/SaveFile4.txt"));
			saveFileSelector.addItem(new File("Saves/SaveFile5.txt"));
		}
	
		public void paintComponent(Graphics g)
		{
			g.setColor(Color.GRAY);
			g.fillOval(0, 300, 350, 150);
			g.fillOval(450, 0, 350, 150);
			try{
				URL url = new URL("https://fiverr-res.cloudinary.com/images/t_main1,q_auto,f_auto,q_auto,f_auto/gigs/204364595/original/86db6005cd51b4f60e71cca277f603a82cf5646a/draw-a-pixel-pokemon-battle-background.png");
				ImageIcon image = new ImageIcon(url);
				g.drawImage(image.getImage(),0,0,800,450,null);
				}catch(Exception e){};
			try{
				ImageIcon image = new ImageIcon("Images/Mimikyu_Link.png");
				g.drawImage(image.getImage(),300,150,-150,250,null);
				}catch(Exception e){};
		
			newScene(g);
			g.setColor(Color.BLACK);
			g.setFont(new Font("TimesRoman", Font.BOLD, 18));
			
			g.drawString("HP: " + player.getHealth(),100,100);
			g.drawString("Name: " + player.getName(),100,50);

			g.drawString("HP: " + enemy.getHealth(),650,100);
			g.drawString("Name: " + enemy.getName(),625,50);
		}

		public void setGameState(int gameState)
		{
			this.gameState = gameState;
		}
		public int getGameState()
		{
			return gameState;
		}

		public void run()
		{
			//creates a new monster and adds it to the monster array
			monsters[0] = new Monster("Goblin", 100, 20, 30);
			monsters[1] = new Monster("Orc", 150, 30, 40);
			monsters[2] = new Monster("Dragon", 300, 50, 80);
			monsters[3] = new Monster("Skeleton", 80, 15, 25);
			monsters[4] = new Monster("Troll", 200, 40, 60);
			monsters[5] = new Monster("Specter", 120, 25, 35);
			monsters[6] = new Monster("Zombie", 100, 20, 30);
			monsters[7] = new Monster("Vampire", 150, 30, 40);
			monsters[8] = new Monster("Werewolf", 200, 40, 50);
			monsters[9] = new Monster("Ghost", 80, 15, 25);
			welcome(gameState);

			enemy = monsters[rand.nextInt(monsters.length)];
			enemy.resetHP();
			// 	System.out.println(enemy);
			player.setHealth(100);
			repaint();
			
		}  

		//welcome player to the game and ask for their name
		//or if they want to boot up an old save
		public void welcome(int gameState)
		{

			//if player chooses to boot up an old save, load the data from the file
			//with a file reader
			if(gameState == 1)
			{
				try{
					BufferedReader input = new BufferedReader(new FileReader(file));
					player.setName(input.readLine());
					player.setHealth(100);
					player.setDamage(Integer.parseInt(input.readLine()));
					player.setSpecial(Integer.parseInt(input.readLine()));
					monsterLevel = Integer.parseInt(input.readLine());

					
					for(Monster monster: monsters)
					{
						for(int m = 0; m < monsterLevel; m++)
							{
								monster.LevelUp();
							}
					}
					input.close();
				}
				catch(Exception e){
				}
			}

			//if player chooses to start a new game, ask for their name
			else if(gameState == 2)
			{
					
					player.setName(NewGame.name);
					player.setHealth(100);
					player.setDamage(40);
					player.setSpecial(100);
			}

		}
	
		public void newScene(Graphics g)
		{
			ImageIcon image = null;
			if(enemy.getName().equals("Goblin")) {
				// add Goblin specific code here
				image = new ImageIcon("Images/Goblin.png");
			} else if(enemy.getName().equals("Orc")) {
				// add Orc specific code here
				image = new ImageIcon("Images/Orc.png");
			} else if(enemy.getName().equals("Dragon")) {
				// add Dragon specific code here
				image = new ImageIcon("Images/Dragon.png");
			} else if(enemy.getName().equals("Skeleton")) {
				// add Skeleton specific code here
				image = new ImageIcon("Images/Skeleton.png");
			} else if(enemy.getName().equals("Troll")) {
				// add Troll specific code here
				image = new ImageIcon("Images/Troll.png");
			} else if(enemy.getName().equals("Specter")) {
				// add Specter specific code here
				image = new ImageIcon("Images/Specter.png");
			} else if(enemy.getName().equals("Zombie")) {
				// add Zombie specific code here
				image = new ImageIcon("Images/Zombie.png");
			} else if(enemy.getName().equals("Vampire")) {
				// add Vampire specific code here
				image = new ImageIcon("Images/Vampire.png");
			} else if(enemy.getName().equals("Werewolf")) {
				// add Werewolf specific code here
				image = new ImageIcon("Images/Werewolf.png");
			} else if(enemy.getName().equals("Ghost")) {
				// add Ghost specific code here
				image = new ImageIcon("Images/Ghost.png");
			}

			if(null != image)
			{
				g.drawImage(image.getImage(),650,0,-150,250,null);
			}
			else
			{
				//System.out.println("No image found");
			}
		}
		public void actionPerformed(ActionEvent e)
		{
			if(e.getSource() == attackButton)
			{
				blockCounter = 0;
				int damage = rand.nextInt(player.getDamage());
				enemy.setHealth(enemy.getHealth() - damage);
				counter += 1;
				int enemyDamage = rand.nextInt(enemy.getDamage());
				player.setHealth(player.getHealth() - enemyDamage);
				
				if (enemy.getHealth() <= 0)
				{
					player.setHealth(100);
					player.setDamage(player.getDamage() + 5);
					player.setSpecial(player.getSpecial() + 15);
					monsterLevelCounter += 1;

					// if monster level counter is 5, level up the monster and reset the counter
					if(monsterLevelCounter == 5)
					{
						monsterLevelCounter = 0;
						monsterLevel += 1;
						for(Monster monster: monsters)
						monster.LevelUp();
					}
						//set up player with a random monster and reset its health
						enemy = monsters[rand.nextInt(monsters.length)];
						enemy.resetHP();
						repaint();
					
				}
				//if player is dead, break out of loop and end game
				else if(player.getHealth() <= 0)
				{
					Main.gameUX.switchGameState(GameUX.GameState.GAME_OVER);
				}
				repaint();
			}
			if(e.getSource() == specialButton)
			{
				if(counter >= 3)
					{
						blockCounter = 0;
						int special = rand.nextInt(player.getSpecial());
						enemy.setHealth(enemy.getHealth() - special);
						counter -= 3;
					}
					else
					{
						//System.out.println("You don't have enough special points, go use a normal attack!.");
					}
					if (enemy.getHealth() <= 0)
					{
						player.setHealth(100);
						player.setDamage(player.getDamage() + 5);
						player.setSpecial(player.getSpecial() + 15);
						monsterLevelCounter += 1;

						// if monster level counter is 5, level up the monster and reset the counter
						if(monsterLevelCounter == 5)
						{
							monsterLevelCounter = 0;
							monsterLevel += 1;
							for(Monster monster: monsters)
							monster.LevelUp();
						}
						
							//set up player with a random monster and reset its health
							enemy = monsters[rand.nextInt(monsters.length)];
							enemy.resetHP();;
							repaint();
						
					}
					
					//if player is dead, break out of loop and end game
					else if(player.getHealth() <= 0)
					{
						Main.gameUX.switchGameState(GameUX.GameState.GAME_OVER);
					}
					repaint();
			}
			if(e.getSource() == blockButton)
			{
				blockCounter += 1;
				if(blockCounter <= 2)
				{
					counter += 1;
				}
				//if player is dead, break out of loop and end game
				else if(player.getHealth() <= 0)
				{
					Main.gameUX.switchGameState(GameUX.GameState.GAME_OVER); 
				}
				repaint();
			}
			if(e.getSource() == saveButton)
			{
				saveData();
			}
			if(e.getSource() == saveFileSelector)
			{
				try{
				BufferedWriter output = new BufferedWriter(new FileWriter((File)saveFileSelector.getSelectedItem()));
				output.write(player.getName() + "\n");
				output.write(player.getDamage() + "\n");
				output.write(player.getSpecial() + "\n");
				output.write(monsterLevel + "\n");
				output.close();
				}
				catch(Exception exception){}
				remove(saveFileSelector);
				this.repaint();
			}
		}
		public void saveData()
		{
			//try{
				//FileWriter fileWrite = new FileWriter("Save.txt");
				//fileWrite.write(player.getName() + "\n" + player.getDamage() + "\n" + player.getSpecial() + "\n" + monsterLevel + "\n");
				//fileWrite.close();
				//}
				//catch(Exception E){
				//}
			this.add(saveFileSelector);
			saveFileSelector.setBounds(600,300,200,50);
			saveFileSelector.addActionListener(this);
			this.repaint();
			
			
			//System.out.println("You have saved your data");
		}
		public void setFile(File file)
		{
			this.file = file;
		}
	}