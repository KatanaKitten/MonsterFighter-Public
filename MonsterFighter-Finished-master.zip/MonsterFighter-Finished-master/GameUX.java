import java.util.*;
import java.lang.*;
import java.io.*;
import java.awt.*;
import java.awt.GraphicsDevice.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import java.net.URL;

public class GameUX extends JFrame
{

	
    public void runGame() {
        Thread gameThread = new Thread(new Runnable() {
            @Override
            public void run() {
                game.run();
            }
        });
        gameThread.start();
    }

	File file = new File("HighScores.txt");
	public HighScore[] highScore = new HighScore[5];	
	

	
	Game game = new Game();
	
	public enum GameState {
		START_MENU,
		NEW_GAME,
		LOAD_GAME,
		GAME_OVER,
		NEW_GAME_STARTED,
		LOAD_GAME_STARTED,
		HIGH_SCORE
	}


	public GameUX()
	{
		//initListeners();
		setupHighScores();
	}


	public void switchGameState(GameState state)
	{
		setSize(800, 450);
		setLocation(0, 0);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
		setResizable(true);
		setLayout(null);

		
		switch(state)
		{
			case START_MENU:
				setContentPane(new StartScreen());
				invalidate();
				validate();
				repaint();
				break;

			case NEW_GAME:
				setContentPane(new NewGame());
				invalidate();
				validate();
				repaint();
				break;

			case LOAD_GAME:
				setContentPane(new LoadGame());
				invalidate();
				validate();
				repaint();
				break;

			case GAME_OVER:
				setContentPane(new GameOver());
				invalidate();
				validate();
				repaint();
				break;

			case NEW_GAME_STARTED:
				game.setGameState(2);
				setContentPane(game);
				invalidate();
				validate();
				repaint();
				runGame();
				break;

			case LOAD_GAME_STARTED:
				game.setGameState(1);
				setContentPane(game);
				invalidate();
				validate();
				repaint();
				runGame();
				break;

			case HIGH_SCORE:
				setContentPane(new HighScoreScreen());
				invalidate();
				validate();
				repaint();
				break;

			
		}
	}
	public void setupHighScores()
	{
		try {
			BufferedReader input = new BufferedReader(new FileReader(file));
			//String line;
			for (int i = 0; i < highScore.length; i++) {
				//line = input.readLine();
				String[] parts = new String[2];
				parts[0] = input.readLine();
				parts[1] = input.readLine();
				highScore[i] = new HighScore(parts[0], Integer.parseInt(parts[1]));
			}
			input.close();
		} catch (Exception exception) {
		}
	}
	public void compareHighScores()
	{
		if (game.monsterLevel > highScore[4].getPlayerScore())
		{
			HighScore newHighScore = new HighScore(game.player.getName(), game.monsterLevel);
			highScore[4] = newHighScore;
		}
	}
	public void sortHighScores()
	{
		
		// Sort high scores in the array by integer
		Arrays.sort(highScore, new Comparator<HighScore>() {
			@Override
			public int compare(HighScore hs1, HighScore hs2) {
				return Integer.compare(hs2.getPlayerScore(), hs1.getPlayerScore());
			}
		});
	}
	public void saveHighScores()
	{
		
		try {
		    BufferedWriter output = new BufferedWriter(new FileWriter(file));
		    for (int i = 0; i < highScore.length; i++) {
		        output.write(highScore[i].getPlayerName() + "\n");
		        output.write(highScore[i].getPlayerScore() + "\n");
		    }
		    output.close();
		} 
		catch (Exception exception) {
		}
	}
}