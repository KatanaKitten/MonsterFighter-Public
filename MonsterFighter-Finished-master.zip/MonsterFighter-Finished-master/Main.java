import java.util.*;
import java.lang.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import java.net.URL;

public class Main
{    
    public static GameUX gameUX = new GameUX();
    
    public static void main(String[] args)
    {
       gameUX.switchGameState(GameUX.GameState.START_MENU);
    }  
}