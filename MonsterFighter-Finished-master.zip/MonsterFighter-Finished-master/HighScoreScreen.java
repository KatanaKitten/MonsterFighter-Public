import java.util.*;
import java.lang.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import java.net.URL;

public class HighScoreScreen extends JPanel implements ActionListener
    {

        JButton backButton = new JButton("Back");
        
        public HighScoreScreen()
        {
            this.setLayout(null);
            this.add(backButton);
            backButton.setBounds(600,375,200,50);
            backButton.addActionListener(this);
        }

        public void paintComponent(Graphics g)
        {
            try{
                URL url = new URL("https://fiverr-res.cloudinary.com/images/t_main1,q_auto,f_auto,q_auto,f_auto/gigs/204364595/original/86db6005cd51b4f60e71cca277f603a82cf5646a/draw-a-pixel-pokemon-battle-background.png");
                ImageIcon image = new ImageIcon(url);
                g.drawImage(image.getImage(),0,0,800,450,null);
                }catch(Exception e){};
            try{
                ImageIcon image = new ImageIcon("Images/Mimikyu_Link.png");
                g.drawImage(image.getImage(),300,150,-150,250,null);
                }catch(Exception e){};
            g.setFont(new Font("Arial", Font.BOLD, 20));
            g.setColor(Color.BLACK);
            g.drawString("High Scores", 10, 100);
            g.drawString("1. " + Main.gameUX.highScore[0].getPlayerName() + " - " + Main.gameUX.highScore[0].getPlayerScore(), 10, 150);
            g.drawString("2. " + Main.gameUX.highScore[1].getPlayerName() + " - " + Main.gameUX.highScore[1].getPlayerScore(), 10, 200);
            g.drawString("3. " + Main.gameUX.highScore[2].getPlayerName() + " - " + Main.gameUX.highScore[2].getPlayerScore(), 10, 250);
            g.drawString("4. " + Main.gameUX.highScore[3].getPlayerName() + " - " + Main.gameUX.highScore[3].getPlayerScore(), 10, 300);
            g.drawString("5. " + Main.gameUX.highScore[4].getPlayerName() + " - " + Main.gameUX.highScore[4].getPlayerScore(), 10, 350);
        }
        
        public void actionPerformed(ActionEvent e)
            {
                if(e.getSource() == backButton)
                {
                    Main.gameUX.switchGameState(GameUX.GameState.START_MENU);
                }
            }
    }