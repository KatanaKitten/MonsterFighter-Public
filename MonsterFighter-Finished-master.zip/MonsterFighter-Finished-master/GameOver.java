import java.util.*;
import java.lang.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import java.net.URL;


//Plan:
//Create a button that says "Play Again"
//Create a button that says "Save last level data"
//Create a button that says "Exit Game"


public class GameOver extends JPanel implements ActionListener
{
	
	JButton playAgainButton = new JButton("Play Again");
	JButton saveDataButton = new JButton("Save last level data");
	JButton exitButton = new JButton("Exit Game");
	private JComboBox<File> saveFileSelector = new JComboBox<File>();

	public GameOver()
	{
		this.setLayout(null);
		this.add(playAgainButton);
		this.add(saveDataButton);
		this.add(exitButton);
	
		playAgainButton.setBounds(300,150,200,50);
		saveDataButton.setBounds(300,200,200,50);
		exitButton.setBounds(300,250,200,50);
	
		playAgainButton.addActionListener(this);
		saveDataButton.addActionListener(this);
		exitButton.addActionListener(this);

		saveFileSelector.addItem(new File("Saves/SaveFile1.txt"));
		saveFileSelector.addItem(new File("Saves/SaveFile2.txt"));
		saveFileSelector.addItem(new File("Saves/SaveFile3.txt"));
		saveFileSelector.addItem(new File("Saves/SaveFile4.txt"));
		saveFileSelector.addItem(new File("Saves/SaveFile5.txt"));

		
	}


	public void paintComponent(Graphics g)
	{
		g.setColor(Color.GRAY);
		g.fillOval(0, 300, 350, 150);
		g.fillOval(450, 0, 350, 150);
		try{
			URL url = new URL("https://fiverr-res.cloudinary.com/images/t_main1,q_auto,f_auto,q_auto,f_auto/gigs/204364595/original/86db6005cd51b4f60e71cca277f603a82cf5646a/draw-a-pixel-pokemon-battle-background.png");
			ImageIcon image = new ImageIcon(url);
			g.drawImage(image.getImage(),0,0,800,450,null);
			}catch(Exception e){};
		try{
			ImageIcon image = new ImageIcon("Images/Mimikyu_Link.png");
			g.drawImage(image.getImage(),300,150,-150,250,null);
			}catch(Exception e){};
		g.setFont(new Font("Arial", Font.BOLD, 20));
		g.setColor(Color.BLACK);
		g.drawString("Game Over", 300, 100);
		g.drawString("your score is: " + Main.gameUX.game.monsterLevel + "!" , 300, 125);
		Main.gameUX.compareHighScores();
		Main.gameUX.sortHighScores();
		Main.gameUX.saveHighScores();
	}

	public void actionPerformed(ActionEvent e)
	{
		
        if(e.getSource() == playAgainButton)
		{
            Main.gameUX.switchGameState(GameUX.GameState.START_MENU);
        }
        if(e.getSource() == saveDataButton)
		{
			this.add(saveFileSelector);
			saveFileSelector.setBounds(500,150,200,50);
			saveFileSelector.setVisible(true);
			saveFileSelector.addActionListener(this);
			this.repaint();
        }
        if(e.getSource() == exitButton)
		{
            System.exit(0);
        }
		if(e.getSource() == saveFileSelector)
		{
			File file = (File)saveFileSelector.getSelectedItem();

			try (FileWriter writer = new FileWriter(file)) {
				writer.write(Main.gameUX.game.player.getName() + "\n");
				writer.write(Main.gameUX.game.player.getDamage() + "\n");
				writer.write(Main.gameUX.game.player.getSpecial() + "\n");
				writer.write("" + Main.gameUX.game.monsterLevel + "\n");
			} catch (IOException ex) {
			}
			remove(saveFileSelector);
			this.repaint();
		}
	}
}