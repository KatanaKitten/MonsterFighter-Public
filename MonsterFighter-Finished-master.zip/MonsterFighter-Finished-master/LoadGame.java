import java.util.*;
import java.lang.*;
import java.io.*;
import java.awt.*;
import java.awt.Graphics2D.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import java.net.URL;

//Plan:
//Create confirm and a back button and print out data within the save file
//so the player can see what they have


//Add save file selector with drop down menu


public class LoadGame extends JPanel implements ActionListener
{

	JButton confirmButton = new JButton("Confirm");
	JButton backButton = new JButton("Back");
	private JComboBox<File> saveFileSelector = new JComboBox<File>();
	//BufferedReader input;

	JLabel characterNameLabel = new JLabel();
	JLabel characterDamageLabel = new JLabel();
	JLabel characterSpecialLabel = new JLabel();
	JLabel monsterLevelLabel = new JLabel();
	
	
	public LoadGame()
	{
		this.setLayout(null);
		this.add(confirmButton);
		this.add(backButton);
		this.add(saveFileSelector);
		confirmButton.setBounds(300,200,200,50);
		backButton.setBounds(300,250,200,50);
		saveFileSelector.setBounds(300,150,200,50);
		confirmButton.setVisible(true);
		backButton.setVisible(true);
		saveFileSelector.setVisible(true);
		confirmButton.addActionListener(this);
		backButton.addActionListener(this);

		saveFileSelector.addItem(new File("Saves/SaveFile1.txt"));
		saveFileSelector.addItem(new File("Saves/SaveFile2.txt"));
		saveFileSelector.addItem(new File("Saves/SaveFile3.txt"));
		saveFileSelector.addItem(new File("Saves/SaveFile4.txt"));
		saveFileSelector.addItem(new File("Saves/SaveFile5.txt"));

		

		
		
	}

	public void paintComponent(Graphics g)
	{
		try{
			URL url = new URL("https://fiverr-res.cloudinary.com/images/t_main1,q_auto,f_auto,q_auto,f_auto/gigs/204364595/original/86db6005cd51b4f60e71cca277f603a82cf5646a/draw-a-pixel-pokemon-battle-background.png");
			ImageIcon image = new ImageIcon(url);
			g.drawImage(image.getImage(),0,0,800,450,null);
			}catch(Exception e){};
		try{
			ImageIcon image = new ImageIcon("Images/Mimikyu_Link.png");
			g.drawImage(image.getImage(),300,150,-150,250,null);
			}catch(Exception e){};

		Graphics2D g2d = (Graphics2D) g;
		
		g.setColor(Color.WHITE);
		g.fillRect(0,40,260,210);
		g2d.setStroke(new BasicStroke(5));
		g2d.setColor(Color.BLACK);
		g2d.drawRect(0,40,260,210);
		
		
		characterNameLabel.setFont(new Font("Arial", Font.BOLD, 18));
		characterDamageLabel.setFont(new Font("Arial", Font.BOLD, 18));
		characterSpecialLabel.setFont(new Font("Arial", Font.BOLD, 18));
		monsterLevelLabel.setFont(new Font("Arial", Font.BOLD, 18));



		try {
			BufferedReader input = new BufferedReader(new FileReader((File)saveFileSelector.getSelectedItem()));
			characterNameLabel.setText("Character Name: " + input.readLine());
			characterDamageLabel.setText("Character Damage: " + input.readLine());
			characterSpecialLabel.setText("Character Special: " + input.readLine());
			int monsterLevel = Integer.parseInt(input.readLine());
			monsterLevelLabel.setText("Monster Level: " + monsterLevel);
			input.close();
		}
		catch (Exception e){
		}
		
		characterNameLabel.setBounds(10, 50, 250, 30);
		characterDamageLabel.setBounds(10, 100, 250, 30);
		characterSpecialLabel.setBounds(10, 150, 250, 30);
		monsterLevelLabel.setBounds(10, 200, 250, 30);
		
		this.add(characterNameLabel);
		this.add(characterDamageLabel);
		this.add(characterSpecialLabel);
		this.add(monsterLevelLabel);
		
		
		// try {
		// input = new BufferedReader(new FileReader((File)saveFileSelector.getSelectedItem()));
		// g.setFont(new Font("Arial", Font.BOLD, 20));
		// g.setColor(Color.BLACK);
		// g.drawString("Data in file:", 10, 100);
		// g.drawString("Character Name: " + input.readLine(), 10, 150);
		// g.drawString("Character Damage: " + input.readLine(), 10, 200);
		// g.drawString("Character Special: " + input.readLine(), 10, 250);
		// int monsterLevel = Integer.parseInt(input.readLine());
		// g.drawString("Monster Level: " + monsterLevel, 10, 300);
		// //System.out.print("I am here");
		// input.close();
		// }
		// catch (Exception e){
		// }
	}

	
    public void actionPerformed(ActionEvent e)
    {
		
        if (e.getSource() == confirmButton)
		{
			Main.gameUX.game.setFile((File)saveFileSelector.getSelectedItem());
			Main.gameUX.switchGameState(GameUX.GameState.LOAD_GAME_STARTED);
		}
		else if (e.getSource() == backButton)
		{
			Main.gameUX.switchGameState(GameUX.GameState.START_MENU);
		}
		else if (e.getSource() == saveFileSelector)
		{
			
			//Main.gameUX.game.setFile((File)saveFileSelector.getSelectedItem());
			//repaint();

			try {
				BufferedReader input = new BufferedReader(new FileReader((File)saveFileSelector.getSelectedItem()));
				characterNameLabel.setText("Character Name: " + input.readLine());
				characterDamageLabel.setText("Character Damage: " + input.readLine());
				characterSpecialLabel.setText("Character Special: " + input.readLine());
				int monsterLevel = Integer.parseInt(input.readLine());
				monsterLevelLabel.setText("Monster Level: " + monsterLevel);
				input.close();
			}
			catch (Exception ex){
			}
		}
    }
}