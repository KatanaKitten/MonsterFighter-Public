import java.util.*;
import java.lang.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import java.net.URL;

//Plan:
//Create a text box where the user can type their name to play the game
//Create a back button to go back to the start screen



public class NewGame extends JPanel implements ActionListener
{
	JTextField nameField = new JTextField(20);
	JButton backButton = new JButton("Back");
	JButton startButton = new JButton("Start");
	JLabel nameLabel = new JLabel("Enter your name: ");
	public static String name;

	public NewGame()
	{
		this.setLayout(null);
		this.add(nameLabel);
		this.add(nameField);
		this.add(backButton);
		this.add(startButton);
		nameLabel.setBounds(300,150,200,50);
		nameField.setBounds(300,200,200,50);
		backButton.setBounds(300,250,200,50);
		startButton.setBounds(300,300,200,50);
		nameLabel.setVisible(true);
		nameField.setVisible(true);
		backButton.setVisible(true);
		startButton.setVisible(true);
		backButton.addActionListener(this);
		startButton.addActionListener(this);
	}


	public void paintComponent(Graphics g)
	{
		g.setColor(Color.GRAY);
		g.fillOval(0, 300, 350, 150);
		g.fillOval(450, 0, 350, 150);
		try{
			URL url = new URL("https://fiverr-res.cloudinary.com/images/t_main1,q_auto,f_auto,q_auto,f_auto/gigs/204364595/original/86db6005cd51b4f60e71cca277f603a82cf5646a/draw-a-pixel-pokemon-battle-background.png");
			ImageIcon image = new ImageIcon(url);
			g.drawImage(image.getImage(),0,0,800,450,null);
			}catch(Exception e){};
		try{
			ImageIcon image = new ImageIcon("Images/Mimikyu_Link.png");
			g.drawImage(image.getImage(),300,150,-150,250,null);
			}catch(Exception e){};
		g.setColor(Color.WHITE);
		g.fillRect(300,150,200,50);
	}

	public void actionPerformed(ActionEvent e)
	{
		
		if(e.getSource() == backButton)
		{
			Main.gameUX.switchGameState(GameUX.GameState.START_MENU);
		}
		else if (e.getSource() == startButton)
		{
			name = nameField.getText();
			Main.gameUX.switchGameState(GameUX.GameState.NEW_GAME_STARTED);
		}
	}
}