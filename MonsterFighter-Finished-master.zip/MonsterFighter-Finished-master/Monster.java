public class Monster
{
    private String name;
    private int health;
    private int max_health; // to avoid infinite loop
    private int damage;
    private int special;
    private static int monsterLevel;

    public Monster()
    {
        this.name = "Monster";
        this.health = 100;
        this.max_health = 100;
        this.damage = 10;
        this.special = 0;
        this.monsterLevel = 0;
    }

    public Monster(String name, int health, int damage, int special)
    {
        this.name = name;
        this.health = health;
        this.max_health = health;
        this.damage = damage;
        this.special = special;
    }

    
    // get/set name
    public String getName()
    {
    return name;
    }
    
    public void setName(String name)
    {
        this.name = name;
    }

    
    // get/set health
    public int getHealth()
    {
        return health;
    }
    
    public void setHealth(int health) 
    {
        this.health = health;
    }

    
    //reset health
    public void resetHP()
    {
        this.health = this.max_health;
    }

    
    // get/set damage
    public int getDamage()
    {
        return damage;
    }
    
    public void setDamage(int damage)
    {
        this.damage = damage;
    }

    
    // get/set special
    public int getSpecial()
    {
        return special;
    }
    
    public void setSpecial(int special)
    {
        this.special = special;
    }

    
    // get/set monsterLevel
    public static int getMonstersLevel()
    {
        return monsterLevel;
    }
    public static void setMonsterLevel(int lvl)
    {
        monsterLevel = lvl;
    }


    //level up monster stats over time
    public void LevelUp()
    {
        this.max_health *= 1.05;
        this.health = this.max_health;
        this.damage += 1;
        this.special += 2;
        //monsterLevel += 1;
    }

    //print out monster
    public String toString()
    {
        return "Name: " + name + ", Health: " + health + ", Damage: " + damage + ", Special: " + special;
    }
}