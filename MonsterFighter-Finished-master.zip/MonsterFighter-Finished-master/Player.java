public class Player
{
    //player stats and name
    private String name;
    private int health;
    private int damage;
    private int special;

    //default constructor
    public Player()
    {
        
    }
    //constructor with parameters
    public Player(String name, int health, int damage, int special)
    {
        this.name = name;
        this.health = health;
        this.damage = damage;
        this.special = special;
    }
    //get/set name
    public String getName()
    {
        return this.name;
    }
    public void setName(String name)
    {
        this.name = name;
    }

    //get/set health
    public int getHealth()
    {
        return this.health;
    }
    public void setHealth(int health)
    {
        this.health = health;
    }

    //get/set damage
    public int getDamage()
    {
        return damage;
    }
    public void setDamage(int damage)
    {
        this.damage = damage;
    }

    //get/set special
    public int getSpecial()
    {
        return special;
    }
    public void setSpecial(int special)
    {
        this.special = special;
    }
    
    //print out character
    public String toString()
    {
        return "Name: " + name + "\nHealth: " + health + "\nDamage: " + damage + "\nSpecial: " + special;
    }
}